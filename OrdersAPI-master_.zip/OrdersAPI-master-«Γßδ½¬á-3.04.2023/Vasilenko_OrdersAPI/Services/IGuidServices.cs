﻿namespace Vasilenko_OrdersAPI.Services
{
    public interface IGuidServices
    {
        Guid Value { get; }
    }
}
